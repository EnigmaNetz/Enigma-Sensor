#pragma once

#include <cassert>

#define BROKER_ASSERT assert
