#pragma once

#include "broker/entity_id.hh"
